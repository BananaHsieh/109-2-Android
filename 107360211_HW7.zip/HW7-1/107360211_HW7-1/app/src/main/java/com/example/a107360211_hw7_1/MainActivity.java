package com.example.a107360211_hw7_1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onNew1(View view) {
        Intent intent = new Intent(this, NewActivity1.class);
        startActivity(intent);
    }
    public void onNew2(View view) {
        Intent intent = new Intent(this, NewActivity2.class);
        startActivity(intent);
    }
    public void onNew3(View view) {
        Intent intent = new Intent(this, NewActivity3.class);
        startActivity(intent);
    }

}