package com.example.a107360211_hw6_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void displayToast(StringBuffer message) {
        Toast.makeText(getApplicationContext(), message,
                Toast.LENGTH_SHORT).show();
    }

    public void onToast(View view) {
        StringBuffer toppings = new
                StringBuffer().append(getString(R.string.toppings_label));
        if  (((CheckBox) findViewById(R.id.chocolate)).isChecked()) {
            toppings.append(getString(R.string.chocolatesyrup));
        }
        if  (((CheckBox) findViewById(R.id.sprinkle)).isChecked()) {
            toppings.append(getString(R.string.sprinkles));
        }
        if  (((CheckBox) findViewById(R.id.nuts)).isChecked()) {
            toppings.append(getString(R.string.crushednuts));
        }
        if  (((CheckBox) findViewById(R.id.cherry)).isChecked()) {
            toppings.append(getString(R.string.cherries));
        }
        if  (((CheckBox) findViewById(R.id.oreo)).isChecked()) {
            toppings.append(getString(R.string.oreocookiecrumbles));
        }
        displayToast(toppings);
    }

}