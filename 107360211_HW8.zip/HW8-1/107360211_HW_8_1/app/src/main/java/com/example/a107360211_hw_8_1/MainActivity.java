package com.example.a107360211_hw_8_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private ImageView image ;
    private int level=0;
    private TextView count;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        image= (ImageView)findViewById(R.id.battery);
        count= (TextView)findViewById(R.id.count);
        image.setImageResource(R.drawable.batter_level);
    }

    public void onMinus(View view) {
        level--;
        if(level<0){
            level = 0;
        }
        image.setImageLevel(level);
        count.setText(String.valueOf(level));

    }

    public void onPlus(View view) {
        level++;
        if(level>6){
            level = 6;
        }
        image.setImageLevel(level);
        count.setText(String.valueOf(level));
    }

}